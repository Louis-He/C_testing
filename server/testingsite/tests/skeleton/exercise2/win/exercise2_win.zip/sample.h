/* Arthor: Louis He
 * Year: 2020
 *
 * This file is for acedemic training purpose only. Do NOT distribute this file without the consent of the arthor.
 */

extern "C" {
void hello1();
void hello2();
void convert_seconds_to_str(int time_difference);
int get_timestamp();
}