extern "C" {
void hello();
}