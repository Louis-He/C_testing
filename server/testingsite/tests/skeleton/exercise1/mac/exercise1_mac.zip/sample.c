#include "sample.h"

#include <stdio.h>

void hello() {
    /* implement your code here */
}